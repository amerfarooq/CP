/*
 * Ghost.cpp
 *
 *  Created on: May 7, 2017
 *      Author: amer
 */

#include "Ghost.h"
#include "Board.h"

Ghost::Ghost() {}

Ghost::Ghost( Board* board, string ghostName )
: m_board( board ),
  m_isSpawned( false ),
  m_cRow( -1 ),
  m_cCol( -1 ),
  m_tRow( -1 ),
  m_tCol( -1 ),
  m_pRow( -1 ),
  m_pCol( -1 ),
  m_respawnTimer( 0 ),
  m_isKilled( false )
{
	if ( ghostName == "Pinky" ) {
		m_color = PINK;
		m_ghostMode = CHASE;
		m_name = "Pinky";
	}
	else if ( ghostName == "Blinky" ) {
		m_color = BLUE;
		m_ghostMode = CHASE;
		m_name = "Blinky";
	}
	else if ( ghostName == "Inky" ) {
		m_color = RED;
		m_ghostMode = CHASE;
		m_name = "Inky";
	}
	else if ( ghostName == "Clyde" ) {
		m_color = ORANGE;
		m_ghostMode = CHASE;
		m_name = "Clyde";
	}
}

struct cellNode {
	int row, col, pRow, pCol;
	GhostDirection dir;

	cellNode( int cr, int cc, int pr, int pc, GhostDirection direction ) {
		row = cr;
		col = cc;
		pRow = pr;
		pCol = pc;
		dir = direction;
	}
};

GhostDirection Ghost::getNextDirection( int sr, int sc, int fr, int fc ) {
	int boardRows = m_board->GetRows();
	int boardCols = m_board->GetColumns();
	
	bool visited[ boardRows ][ boardCols ];
	for ( int i = 0; i < boardRows; ++i ) {
		for ( int j = 0; j < boardCols; ++j ) {
			visited[i][j] = false;
		}
	}
	
	queue< cellNode > toVisit;
	cellNode src( m_cRow, m_cCol, m_pRow, m_pCol, NONE );
	bool onFirstTile = true;
	
	visited[m_cRow][m_cCol] = true;
	toVisit.push( src );
	
	while ( !toVisit.empty() ) {
		cellNode crnt = toVisit.front();

		// Looking at cell above current node.
		if ( isValid( crnt.row - 1, crnt.col ) and      	   // Check if row and col are within board bounds.
	   	     !(*m_board)( crnt.row - 1, crnt.col )and   // Check if cell above has no bricks.
		     !visited[crnt.row -1 ][crnt.col] and   		   // Check if above cell has been visited before.
		     crnt.row - 1 != crnt.pRow			   	   // Check if above cell is previous location.
		     )
		{
			// In case Ghost is on its starting tile
			// i.e. the tile at which BFS begins,
			// it will set the direction around
			// it accordingly, after which those
			// directions will be utilized as the
			// search propogates.
			if ( onFirstTile ) {
				crnt.dir = UP;
			}	

			// Check if above tile is the destination tile.
			if ( crnt.row - 1 == fr and crnt.col == fc ) {
				return crnt.dir;
			}
			else {
				// Set status of current tile as visited and push
				// tile above to the queue for further exploration.
				visited[ crnt.row ][ crnt.col ] = true;
				toVisit.push( cellNode( crnt.row - 1, crnt.col, crnt.row, crnt.col, crnt.dir ));
			}
		}
		// Looking at cell below current node.
		if ( isValid( crnt.row + 1, crnt.col ) and
		     !(*m_board)( crnt.row + 1, crnt.col ) and
		     !visited[crnt.row + 1 ][crnt.col] and
		     crnt.row + 1 != crnt.pRow )
		{
			if ( onFirstTile ) {
				crnt.dir = DOWN;
			}	

			if ( crnt.row + 1 == fr and crnt.col == fc ) {
				return crnt.dir;
			}
			else {
				visited[ crnt.row ][ crnt.col ] = true;
				toVisit.push( cellNode( crnt.row + 1, crnt.col, crnt.row, crnt.col, crnt.dir ));
			}
		}
		// Looking at cell right of current node.
		if ( isValid( crnt.row, crnt.col + 1 ) and
		     !(*m_board)( crnt.row, crnt.col + 1 ) and
		     !visited[crnt.row][crnt.col + 1] and
		      crnt.col + 1 != crnt.pCol )
		{
			if ( onFirstTile ) {
				crnt.dir = RIGHT;
			}	
			if ( crnt.row == fr and crnt.col + 1 == fc ) {
				return crnt.dir;
			}
			else {
				visited[ crnt.row ][ crnt.col ] = true;
				toVisit.push( cellNode( crnt.row, crnt.col + 1, crnt.row, crnt.col, crnt.dir ));
			}
		}
		// Looking at cell left of current node.
		if ( isValid( crnt.row, crnt.col - 1 ) and
		     !(*m_board)( crnt.row, crnt.col - 1 ) and
		     !visited[crnt.row][crnt.col - 1] and
		     crnt.col - 1 != crnt.pCol )
		{
			if ( onFirstTile ) {
				crnt.dir = LEFT;
			}	
			if ( crnt.row == fr and crnt.col - 1 == fc ) {
				return crnt.dir;
			}
			else {
				toVisit.push( cellNode( crnt.row, crnt.col - 1, crnt.row, crnt.col, crnt.dir ));
			}
		}
		onFirstTile = false;
		toVisit.pop();
	}
	return NONE;    // In case Bomberman not found
}

int targetRow;
int targetCol;
void setScatterModeTargets() {
	
	switch ( GetRandInRange(1,4) ) {
			
		case 1:
				targetRow = 1;
				targetCol = 1;
				break;
				
		case 2: 
				targetRow = 11;
				targetCol = 1;
				break;
				
		case 3: 
				targetRow = 11;
				targetCol = 15;
				break;
		case 4:
				targetRow = 1;
				targetCol = 15;		
				break;

	}
}

void Ghost::move() {
	if ( !m_isSpawned )
		return;

	if ( m_ghostMode == CHASE ) {
		targetRow = m_board->getBomberman().getCurrentRow();
		targetCol = m_board->getBomberman().getCurrentCol();
		
	}
	else {
		setScatterModeTargets();
	}	
	
	GhostDirection nextDirection = getNextDirection( m_cRow, m_cCol, targetRow, targetCol );

	if ( nextDirection == NONE ) {
		setScatterModeTargets();
		nextDirection = getNextDirection( m_cRow, m_cCol, targetRow, targetCol );
	}

	switch ( nextDirection ) {

		case UP:
			moveUp();
			break;

		case DOWN:
			moveDown();
			break;

		case RIGHT:
			moveRight();
			break;

		case LEFT:
			moveLeft();
			break;
			
		case NONE:	
			
			int randDir = rand() % 4;
			switch ( randDir ) {

				case 1:
					moveUp();
					break;
				case 2:
					moveDown();
					break;
				case 3:
					moveLeft();
					break;
				case 4:
					moveRight();
					break;			
			}
			break;
			
	}
}

void Ghost::moveUp() {
	if ( m_cRow - 1  < 0 ) return;

	Cell& aboveCell = (*m_board)( m_cRow - 1, m_cCol );
	Cell& currentCell = (*m_board)( m_cRow, m_cCol );

	if ( !aboveCell ) {
	
		if ( aboveCell.hasBomberman() ) {
			if ( m_ghostMode != FRIGHTENED ) {
				currentCell.removeGhost( this );
				m_board->getBomberman().inflictGhostDamage();
				return;
			}
			else {
				currentCell.removeGhost( this );
				kill();
				return;
			}
		}
		aboveCell.addGhost( this );
		currentCell.removeGhost( this );
		m_pCol = m_cCol;
		m_pRow = m_cRow;
		--m_cRow;
	}
}

void Ghost::moveDown() {
	if ( m_cRow + 1 > m_board->GetRows() ) return;

	Cell& belowCell = (*m_board)( m_cRow + 1, m_cCol );
	Cell& currentCell = (*m_board)( m_cRow, m_cCol );

	if ( !belowCell ) {
	
		if ( belowCell.hasBomberman() ) {
			
			if ( m_ghostMode != FRIGHTENED ) {
				currentCell.removeGhost( this );
				m_board->getBomberman().inflictGhostDamage();
				return;
			}
			else {
				currentCell.removeGhost( this );
				kill();
				return;
			}	
		}
		belowCell.addGhost( this );
		currentCell.removeGhost( this );
		m_pCol = m_cCol;
		m_pRow = m_cRow;
		++m_cRow;
	}
}

void Ghost::moveRight() {
	if ( m_cCol + 1 > m_board->GetColumns() ) return;

	Cell& rightCell = (*m_board)( m_cRow, m_cCol + 1 );
	Cell& currentCell = (*m_board)( m_cRow, m_cCol );

	if ( !rightCell ) {

		if ( rightCell.hasBomberman() ) {
			if ( m_ghostMode != FRIGHTENED ) {
				currentCell.removeGhost( this );
				m_board->getBomberman().inflictGhostDamage();
				return;
			}	
			else {
				currentCell.removeGhost( this );
				kill();
				return;
			}	
		}
		rightCell.addGhost( this );
		currentCell.removeGhost( this );
		m_pCol = m_cCol;
		m_pRow = m_cRow;
		++m_cCol;
	}
}

void Ghost::moveLeft() {
	if ( m_cCol - 1 < 0 ) return;

	Cell& leftCell = (*m_board)( m_cRow, m_cCol - 1 );
	Cell& currentCell = (*m_board)( m_cRow, m_cCol );

	if ( !leftCell ) {
		
		if ( leftCell.hasBomberman() ) {
			if ( m_ghostMode != FRIGHTENED ) {
				currentCell.removeGhost( this );
				m_board->getBomberman().inflictGhostDamage();	
				return;
			}	
			else {
				currentCell.removeGhost( this );	
				kill();
				return;
			}	
		}
		leftCell.addGhost( this );
		currentCell.removeGhost( this );
		m_pCol = m_cCol;
		m_pRow = m_cRow;
		--m_cCol;
	}
}

bool Ghost::isValid( int row, int col ) {
	if ( row < m_board->GetRows() and row >= 0 and
	     col < m_board->GetColumns() and col >= 0 )
		return true;
	else
		return false;
}

int Ghost::getRespawnTimer() const {
	return m_respawnTimer;
}

void Ghost::incrementRespawnTimer() {
	++m_respawnTimer;
}


void Ghost::resetRespawnTimer() {
	m_respawnTimer = 0;
}

void Ghost::kill() {
	m_isKilled = true;
	m_isSpawned = false;
	m_board->decrementGhostCounter();

	if ( m_cRow != -1 and m_cCol != -1 )
		(*m_board)( m_cRow, m_cCol ).removeGhost( this );
	
	m_cRow = -1;
	m_cCol = -1;

}

bool Ghost::isKilled() const {
	return m_isKilled;
}

void Ghost::setGhostAlive() {
	m_isKilled = false;
}

void Ghost::setSpawnStatus( bool status ) {
	m_isSpawned = status;
}

bool Ghost::isSpawned() const {
	return m_isSpawned;
}

bool Ghost::shouldBeSpawned() const {
	float brickRatio = (float) m_board->getRemainingBricks() / m_board->getTotalBricks();

	if ( m_name == "Pinky" ) {
		return true;
	}
	else if ( m_name == "Blinky" ) {
		return true;
	}
	
	else if ( m_name == "Inky" ) {
		if ( brickRatio <= 0.3 )
			return true;
		else
			return false;
	}
	
	else if ( m_name == "Clyde" ) {
		if ( brickRatio <= 0.7 )
			return true;
		else
			return false;
	}
	cout << "Invalid m_name in Ghost::shouldBeSpawned()" << endl;
	return false;
}

void Ghost::setSpawnRow( int rowDistance ) {
	int bmRow = m_board->getBomberman().getCurrentRow();
	int totalRows = m_board->GetRows();

	/* If the rows above and below Bomberman are valid,
	 * choose between either one.
	 */
	if ( bmRow + rowDistance < totalRows-2 and bmRow - rowDistance > 0 ) {
		switch ( GetRandInRange( 1, 2 ) ) {

		case 1:
			m_cRow = bmRow + rowDistance;
			break;

		case 2:
			m_cRow = bmRow - rowDistance;
			break;
		}
	}
	else if ( bmRow + rowDistance < totalRows-2 ) {
		m_cRow = bmRow + rowDistance;
	}
	else {
		m_cRow = bmRow - rowDistance;
	}
}

void Ghost::setSpawnColumn() {
	if ( m_cRow != -1 ) {

		vector< int > uniqueColumns;
		for ( int i = 1; i < m_board->GetColumns()-1; ++i ) {
			uniqueColumns.push_back(i);
		}
		random_shuffle( uniqueColumns.begin(), uniqueColumns.end() );

		for ( int i = 0; i < uniqueColumns.size(); ++i ) {

			int col = uniqueColumns.at(i);
			int bmCol = m_board->getBomberman().getCurrentCol();

			if ( col != bmCol and                                        // i is not Bomberman's column.
				 col != bmCol + 1 and	                              // i is not right of Bomberman's column.
				 col != bmCol - 1 and                                 // i is not left of Bomberman's column.
				 !(*m_board)( m_cRow, col ) and            // i does not have any bricks.
				 !(*m_board)( m_cRow, col ).hasGhost()     // i does not have any ghost.
				)
			{
				m_cCol = col;
				return;
			}
		}

		// In-case suitable column not found, chose random row
		// and check for suitable column. Repeat until column found.
		if ( m_cCol == -1 ) {
			setSpawnRow( GetRandInRange( 2, m_board->GetRows() - 2 ));
			setSpawnColumn();
		}
	}
	else {
		cout << "Ghost::setSpawnRow called when cRow uninitialized." << endl;
	}
}

void Ghost::spawn( GhostMode mode ) {
	
	// If Ghost being spawned after first time,
	// ensure it removes itself from its
	// current row first before spawning.
	if ( m_cRow != -1 and m_cCol != -1 )
		(*m_board)( m_cRow, m_cCol ).removeGhost( this );
	
	if ( m_name == "Pinky" ) {
		setSpawnRow(4);
	}
	else if ( m_name == "Blinky" ){
		setSpawnRow( 3 );
	}
	else {
		setSpawnRow(2);
	}
	setSpawnColumn();

	(*m_board)( m_cRow, m_cCol ).addGhost( this );
	m_isSpawned = true;
	m_ghostMode = mode;
}

void Ghost::respawn() {
/* This function is called when ghost is to be removed from
 * its current cell and its spawnStatus set to false. This
 * function is called by Board::totalReset();
 */
	if ( m_cRow != -1 and m_cCol != -1 )
		(*m_board)( m_cRow, m_cCol ).removeGhost( this );
  
	setSpawnStatus( false );
}

void Ghost::setMode( GhostMode mode ) {
	// Ghost Mode is changed by outside entities.
	// Everytime FRIGHTENED mode is triggered,
	// ghost should turn take a 180 turn,
	// but only if it has been spawned.
	if ( m_isSpawned ) {
	
		if ( mode == FRIGHTENED ) {
			(*m_board)( m_cRow, m_cCol).removeGhost( this );
		
			m_cRow = m_pRow;
			m_cCol = m_pCol;
	
			(*m_board)( m_cRow, m_cCol ).addGhost( this );
		}
		m_ghostMode = mode;
	}
}

ColorNames Ghost::getGhostColor() const {
	return m_color;
}

GhostMode Ghost::getGhostMode() const {
	return m_ghostMode;
}

string Ghost::getGhostName() const {
	return m_name;
}

int Ghost::getCurrentRow() const {
	return m_cRow;
}

int Ghost::getCurrentCol() const {
	return m_cCol;
}

int Ghost::getPreviousRow() const {
	return m_pRow;
}

int Ghost::getPreviousCol() const {
	return m_pCol;
}

int Ghost::getTargetRow() const {
	return m_tRow;
}

int Ghost::getTargetCol() const {
	return m_tCol;
}

void Ghost::setTarget( int row, int col ) {
	m_tRow = row;
	m_tCol = col;
}

void Ghost::resetCurrentPosition() {
	m_cRow = m_cCol = -1;
	m_pRow = m_pCol = -1;
}

ostream& operator<<( ostream& op, const Ghost* ptr ) {
	op << ptr->getGhostName() << " at " << ptr->getCurrentRow() << "," << ptr->getCurrentCol();
	return op;
}