#ifndef Bomberman_CPP_
#define Bomberman_CPP_

#include "Board.h"
#include "util.h"
#include <iostream>
#include <time.h>
#include <string>
#include <cmath>
using namespace std;

void SetCanvasSize(int width, int height) {
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, width, 0, height, -1, 1); // set the screen size to given width and height.
	glMatrixMode (GL_MODELVIEW);
	glLoadIdentity();
}


Board* b;
void GameDisplay() {

	glClearColor(0, 0, 0.0, 0 );
	glClear(GL_COLOR_BUFFER_BIT);

	b->Draw();

	glutSwapBuffers();

}

void NonPrintableKeys(int key, int x, int y) {

	if (key == GLUT_KEY_LEFT ) {
		b->getBomberman().moveLeft();
	}

	else if (key == GLUT_KEY_RIGHT ) {
		b->getBomberman().moveRight();
	}

	else if (key == GLUT_KEY_UP) {
		b->getBomberman().moveUp();
	}

	else if (key == GLUT_KEY_DOWN ) {
		b->getBomberman().moveDown();
	}

	 glutPostRedisplay();
}

// TODO: Put these on top of timer func.
int globalTimer = 0;
int bombTimer = 0;
int ghostSpeed = 6;
int ghostMovementTimer = 0;
int frightenedModeTimer = 0;
int scatterModeTimerOn = 0;
int scatterModeTimerOff = 0;
int powerUpTimer = 0;
bool inScatterMode = false;


void PrintableKeys(unsigned char key, int x, int y) {
	if ( key == 27 ) {
		exit(1);
	}
	if ( key == 'b' || key == 'B' ) {
		if ( !b->getBomberman().isBombDropped() ) {    /* If bomb has not been dropped. */
			b->getBomberman().dropBomb();
		}
	}
	if ( key == 'P' || key == 'p' ) {
		ghostMovementTimer = -100000;
	}
	if ( key == 'R' || key == 'r' ) {
		ghostMovementTimer = 0;
	}
	if ( key == 'K' || key == 'k' ) {
		b->totalReset();
	}
	glutPostRedisplay();
}

void resetTimers() {
	globalTimer = 0;
	bombTimer = 0;
	ghostSpeed = 6;
	ghostMovementTimer = 0;
	frightenedModeTimer = 0;
	scatterModeTimerOn = 0;
	scatterModeTimerOff = 0;
	powerUpTimer = 0;
	inScatterMode = false;
}

void Timer( int m ) {
	glutTimerFunc( 100.0, Timer, 0 );
	
	// When game is totally reset, set all timers
	// to 0 and then remove reset state so this
	// condition only executes once.
	if ( b->isTotalReset() ) {
		resetTimers();
		b->removeResetState();
	}

	// Check if bomb is dropped and if it is, start
	// a timer that explodes it after 1 sec.
	if ( b->getBomberman().isBombDropped()) {

		++bombTimer;

		if ( bombTimer == 10 /* 1 sec */ ) {
			b->getBomberman().blowCell();
			b->getBomberman().setBombDropped( false );
			bombTimer = 0;
		}
	}	
	
	++globalTimer;
	// ghostSpeed is basically the number of (tenth) seconds
	// after which the ghost takes a decision to move.
	// Therefore, the lesser the seconds, the faster
	// the ghost decides and the faster it moves.
	
	if ( globalTimer == 100 ) {
		ghostMovementTimer = 4;
		ghostSpeed = 5;
	}	
	if ( globalTimer == 200 ) {
		ghostMovementTimer = 3;
		ghostSpeed = 4;
		b->generatePowerUp();    	// Power up generated at 20 sec mark in random location.
	}
	if ( globalTimer == 300 ) {    // Greater than 30 sec.
		ghostMovementTimer = 2;
		ghostSpeed = 3;
	}
	if ( globalTimer >= 200 ) {
		++powerUpTimer;

		if ( !b->getBomberman().isPowerUpEaten() and powerUpTimer  >= 40 ) {
			b->removePowerUp();
			b->generatePowerUp();
			powerUpTimer = 0;
		}	
	}	
		
	// Move ghosts after a specific amount of time and reset its timer. 
	++ghostMovementTimer;
	if ( ghostMovementTimer == ghostSpeed ) {
		b->moveGhosts();
		ghostMovementTimer = 0;
	}
	// Check if ghosts are frightened. If so,  change their
	// mode to frightened and start a timer to keep the
	// ghosts in this mode for a specific amount
	// of time.
	if ( b->getGhostMode() == FRIGHTENED ) {
		++frightenedModeTimer;
		
		if ( frightenedModeTimer == 50 /* 5 sec */ )  {
			b->setGhostMode( CHASE );
			b->setEnergizerEaten( false );    // Since eating energizer makes ghost scared.
			frightenedModeTimer = 0;
			glutPostRedisplay();
			return;
		}	
	}
	
	// If ghosts are in scatter mode and not frightened, count
	// down the scatterModeTimerOff which will allow the ghosts
	// to stay in scatter mode for 5 seconds. After this, the
	// Chase mode is set for 10 seconds.
	if ( inScatterMode ) {
		++scatterModeTimerOff;
		
		if ( scatterModeTimerOff == 30 and b->getGhostMode() != FRIGHTENED ) {
			inScatterMode = false;
			b->setGhostMode( CHASE );
			scatterModeTimerOff = 0;
		}	
	}	
		
	if ( !inScatterMode ) {
		++scatterModeTimerOn;	
		
		if ( scatterModeTimerOn == 100 and b->getGhostMode() != FRIGHTENED ) {
			inScatterMode = true;
			b->setGhostMode( SCATTER );
			scatterModeTimerOn = 0;
		}
	}
	glutPostRedisplay();
}


int main( int argc, char* argv[] ) {

	b = new Board( 60, 60 ); 

	int width = 1020, height = 840; 
	b->InitalizeBoard( width, height );
	InitRandomizer(); 
	glutInit( &argc, argv ); 
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA); // we will be using color display mode
	glutInitWindowPosition( 50, 50 ); // set the initial position of our window
	glutInitWindowSize( width, height ); // set the size of our window
	glutCreateWindow( "Bomberman" ); 
	SetCanvasSize(width, height); // set the number of pixels...

#ifdef WITH_TEXTURES
	RegisterTextures();
#endif
	glutDisplayFunc( GameDisplay );
	glutSpecialFunc( NonPrintableKeys ); 
	glutKeyboardFunc( PrintableKeys ); 
	glutTimerFunc( 1000.0, Timer, 0 );
	glutMainLoop();
	return 1;
}

#endif 
