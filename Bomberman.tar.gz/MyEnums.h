/*
 * MyEnums.h
 *
 *  Created on: May 7, 2017
 *      Author: amer
 */

#ifndef MYENUMS_H_
#define MYENUMS_H_

enum BoardParts {
	NILL, S_BRICK, G_BRICK, R_BRICK, BOMBERMAN, BOMB
};

enum ExplosionMode {
	NORMAL, BRICKS_ONLY
};

enum GhostDirection {
	NONE, UP, DOWN, LEFT, RIGHT
};

enum GhostMode {
	CHASE, SCATTER, FRIGHTENED
};


#endif /* MYENUMS_H_ */
