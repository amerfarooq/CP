#include "Bomberman.h"
#include "Board.h"

Bomberman::Bomberman( Board* board, int sRow, int sCol )
: m_board( board ),
  m_sRow( sRow ),
  m_sCol( sCol ),
  m_cRow( m_sRow ),
  m_cCol( m_sCol ),
  m_bRow( -1 ),
  m_bCol( -1 ),
  m_isBombDropped( false ),
  m_noOfLives( 3 ),
  m_bombRadius( 1 ),
  m_score( 0 ),
  m_isPowerUpEaten( false )
{
	(*m_board)( m_sRow, m_sCol ).setBomberman( true );
}

void Bomberman::moveUp() {
	 if ( m_cRow - 1  < 0 ) return;

	 Cell& aboveCell = (*m_board)( m_cRow - 1, m_cCol );
	 Cell& currentCell = (*m_board)( m_cRow, m_cCol );

	 if ( !aboveCell ) {
		 if ( aboveCell.hasGhost() ) {
			 if ( m_board->getGhostMode() == FRIGHTENED ) {

				 m_score += aboveCell.getNoOfGhosts() * 500;
				 aboveCell.killGhosts();
			 }
			 else {
				 currentCell.setBomberman( false );
				 inflictGhostDamage();
				 return;
			 }
		 }
		 if ( aboveCell.hasEnergizer() and !m_board->isEnergizerEaten()) {
		 	aboveCell.setEnergizer( false );
		 	m_board->setGhostMode( FRIGHTENED );
		 	m_board->setEnergizerEaten( true );
		 }
		 if ( aboveCell.hasPowerUp() ) {
		 	m_isPowerUpEaten = true;
		 	aboveCell.setPowerUp( false );
		 	m_bombRadius = 2;
		 }
		 currentCell.setBomberman( false );
		 aboveCell.setBomberman( true );
		 --m_cRow;
	 }
}

void Bomberman::moveDown() {
	if ( m_cRow + 1 > m_board->GetRows() ) return;

	Cell& belowCell = (*m_board)( m_cRow + 1, m_cCol );
	Cell& currentCell = (*m_board)( m_cRow, m_cCol );

	if ( !belowCell ) {

		if ( belowCell.hasGhost() ) {
			if ( m_board->getGhostMode() == FRIGHTENED ) {

				m_score = belowCell.getNoOfGhosts() * 500;
				belowCell.killGhosts();
			}
			else {
				currentCell.setBomberman( false );
				inflictGhostDamage();
				return;
			}
		}
		if ( belowCell.hasEnergizer() and !m_board->isEnergizerEaten()) {
		 	belowCell.setEnergizer( false );
		 	m_board->setGhostMode( FRIGHTENED );
		 	m_board->setEnergizerEaten( true );
		 }
		 if ( belowCell.hasPowerUp() ) {
		 	m_isPowerUpEaten = true;
		 	belowCell.setPowerUp( false );
		 	m_bombRadius = 2;
		 }
		currentCell.setBomberman( false );
		belowCell.setBomberman( true );
		++m_cRow;
	}
}

void Bomberman::moveRight() {
	if ( m_cCol + 1 > m_board->GetColumns() + 1 ) return;

	Cell& currentCell = (*m_board)( m_cRow, m_cCol );
	
	bool isPortal = false;
	if ( m_cRow == 6 and m_cCol == 16 ) {
		isPortal = true;
	}

	Cell& rightCell = ( isPortal ) ? 
					  (*m_board)( m_cRow, 0 ) : 
					  (*m_board)( m_cRow, m_cCol + 1 );

	if ( !rightCell ) {

		if ( rightCell.hasGhost() ) {
			if ( m_board->getGhostMode() == FRIGHTENED ) {
				m_score = rightCell.getNoOfGhosts() * 500;
				rightCell.killGhosts();
			}
			else {
				currentCell.setBomberman( false );
				inflictGhostDamage();
				return;
			}
		}
		if ( rightCell.hasEnergizer() and !m_board->isEnergizerEaten()) {
		 	rightCell.setEnergizer( false );
		 	m_board->setGhostMode( FRIGHTENED );
		 	m_board->setEnergizerEaten( true );
		}
		if ( rightCell.hasPowerUp() ) {
			m_isPowerUpEaten = true;
			rightCell.setPowerUp( false );
		 	m_bombRadius = 2;
		}
		currentCell.setBomberman( false );
		rightCell.setBomberman( true );
		
		if ( isPortal ) m_cCol = 0;
		else ++m_cCol;
	}
}

void Bomberman::moveLeft() {
	if ( m_cCol - 1 < -1 ) return;

	Cell& currentCell = (*m_board)( m_cRow, m_cCol );

	// If current cell is 6,0 then next cell will be 6,16
	bool isPortal = false;
	if ( m_cRow == 6 and m_cCol == 0 ) {
		isPortal = true;
	}

	Cell& leftCell = ( isPortal ) ? 
					  (*m_board)( m_cRow, 16 ) : 
					  (*m_board)( m_cRow, m_cCol - 1 );
	
	if ( !leftCell ) {

		if ( leftCell.hasGhost() ) {
			if ( m_board->getGhostMode() == FRIGHTENED ) {
				m_score = leftCell.getNoOfGhosts() * 500;
				leftCell.killGhosts();
			}
			else {
				currentCell.setBomberman( false );
				inflictGhostDamage();
				return;
			}
		}
		if ( leftCell.hasEnergizer() and !m_board->isEnergizerEaten()) {
		 	leftCell.setEnergizer( false );
		 	m_board->setGhostMode( FRIGHTENED );
		 	m_board->setEnergizerEaten( true );
		 }
		if ( leftCell.hasPowerUp() ) {
			m_isPowerUpEaten = true;
			leftCell.setPowerUp( false );
		 	m_bombRadius = 2;
		}
		currentCell.setBomberman( false );
		leftCell.setBomberman( true );
		
		if ( isPortal ) m_cCol = 16;
		else --m_cCol;
	}
}

void Bomberman::resetCounters() {
	m_score = 0;
	m_noOfLives = 3;
}

void Bomberman::respawn() {
	(*m_board)( m_cRow, m_cCol ).setBomberman( false );
	m_cRow = m_sRow;
	m_cCol = m_sCol;
	//m_isPowerUpEaten = false;
	m_isBombDropped = false;
	//m_bombRadius = 1;
	m_bCol = -1;
	m_bRow = -1;
	(*m_board)( m_cRow, m_cCol ).setBomberman( true );
}

int Bomberman::getCurrentRow() const {
	return m_cRow;
}

int Bomberman::getCurrentCol() const {
	return m_cCol;
}

int Bomberman::getScore() const {
	return m_score;
}

int Bomberman::getNoOfLives() const {
	return m_noOfLives;
}

void Bomberman::dropBomb() {
	(*m_board)( m_cRow, m_cCol ).setBomb( true );
	m_isBombDropped = true;
	m_bRow = m_cRow;
	m_bCol = m_cCol;
}

bool Bomberman::isBombDropped() {
	return m_isBombDropped;
}

void Bomberman::setBombDropped( bool status ) {
	m_isBombDropped = status;

	if ( status == false ) {
		(*m_board)( m_bRow, m_bCol ).setBomb( false );
		m_bRow = -1;
		m_bCol = -1;
	}
}

void Bomberman::setBombRadius( int radius ) {
	m_bombRadius = radius;
}

void Bomberman::blowCell( int row, int col, ExplosionMode mode ) {
	/* -1,-1 are default values which indicate to the function
	 * that blowUp() should be called on the current location
	 * of the bomberman. Otherwise, the values of row and col
	 * passed to the function are used.*/
	if ( row == -1 and col == -1 ) {
		row = m_bRow;
		col = m_bCol;
	}
	if ( row < m_board->GetRows() and row >= 0 and col < m_board->GetColumns() and col >= 0 ) {

		if ( mode == NORMAL ) {
			Cell& currentCell = (*m_board)( row, col );

			/* Check if Bomberman is on current location */
			if ( currentCell.hasBomberman() )
				inflictExplosionDamage();
			
			if ( currentCell.hasGhost() )
				currentCell.killGhosts();

			blowUp( row, col );
			blowDown( row, col );
			blowRight( row, col );
			blowLeft( row, col );
		}
		else if ( mode == BRICKS_ONLY ) {
			blowUp( row, col, BRICKS_ONLY );
			blowDown( row, col, BRICKS_ONLY );
			blowRight( row, col, BRICKS_ONLY );
			blowLeft( row, col, BRICKS_ONLY );
		}
		(*m_board)( row, col ).setBomb( false );
	}
}

void Bomberman::blowUp( int row, int col, ExplosionMode mode ) {

	for ( int i = 1; i <= m_bombRadius; ++i ) {
		/* To ensure we remain within array bounds */
		if ( row - i >= 0 ) {

			Cell& aboveCell = (*m_board)( row - i, col );

			/* If aboveCell has no bricks, and mode is NORMAL
			 * then if aboveCell has Bomberman, it will
			 * suffer explosion damage.
			 */
			if ( !aboveCell and mode == NORMAL ) {

				if ( aboveCell.hasBomberman() ) {
					inflictExplosionDamage();
				}
				if ( aboveCell.hasGhost() ) {
					aboveCell.killGhosts();
				}
			}
			else {
				int brick = aboveCell.getBrick();

				if ( brick == G_BRICK ) {
					m_score += 100;
					m_board->removeCell( row - i, col );
				}
				else if ( brick == R_BRICK ) {
					m_score += 200;
					m_board->removeCell( row - i, col );
					blowCell( row - i, col, BRICKS_ONLY );
				}
			}
		}
	}
}

void Bomberman::blowDown( int row, int col, ExplosionMode mode ) {

	for ( int i = 1; i <= m_bombRadius; ++i ) {
		if ( row + i >= 0 ) {

			Cell& belowCell = (*m_board)( row + i, col );

			if ( !belowCell ) {

				if ( mode == NORMAL ) {
					if ( belowCell.hasBomberman() ) {
						inflictExplosionDamage();
					}
					if ( belowCell.hasGhost() ) {
						m_score += 300;
						belowCell.killGhosts();
					}
				}
			}
			else {
				int brick = belowCell.getBrick();

				if ( brick == G_BRICK ) {
					m_score += 100;
					m_board->removeCell( row + i, col );
				}
				else if ( brick == R_BRICK ) {
					m_score += 200;
					m_board->removeCell( row + i, col );
					blowCell( row + i, col, BRICKS_ONLY );
				}
			}
		}
	}
}

void Bomberman::blowRight( int row, int col, ExplosionMode mode ) {

	for ( int i = 1; i <= m_bombRadius; ++i ) {
		if ( col + i >= 0 ) {

			Cell& rightCell = (*m_board)( row, col + i );

			if ( !rightCell ) {

				if ( mode == NORMAL ) {
					if ( rightCell.hasBomberman() ) {
						inflictExplosionDamage();
					}
					if ( rightCell.hasGhost() ) {
						m_score += 300;
						rightCell.killGhosts();
					}
				}
			}
			else {
				int brick = rightCell.getBrick();

				if ( brick == G_BRICK ) {
					m_score += 100;
					m_board->removeCell( row, col + i );
				}
				else if ( brick == R_BRICK ) {
					m_score += 200;
					m_board->removeCell( row, col + i );
					blowCell( row, col + i, BRICKS_ONLY );
				}
			}
		}
	}
}

void Bomberman::blowLeft( int row, int col, ExplosionMode mode ) {

	for ( int i = 1; i <= m_bombRadius; ++i ) {
		if ( col - i >= 0 ) {

			Cell& leftCell = (*m_board)( row, col - i );

			if ( !leftCell ) {
				if ( mode == NORMAL ) {
					if ( leftCell.hasBomberman() ) {
						inflictExplosionDamage();
					}
					if ( leftCell.hasGhost() ) {
						m_score += 300;
						leftCell.killGhosts();
					}
				}
			}
			else {
				int brick = leftCell.getBrick();

				if ( brick == G_BRICK ) {
					m_score += 100;
					m_board->removeCell( row, col - i );
				}
				else if ( brick == R_BRICK ) {
					m_score += 200;
					m_board->removeCell( row, col - i );
					blowCell( row, col - i, BRICKS_ONLY );
				}
			}
		}
	}
}

void Bomberman::inflictExplosionDamage() {
	/* If last life, reset board. */
	if ( m_noOfLives == 1 ) {
		m_board->setGameLost();
	}
	else {
		--m_noOfLives;
	}
}

void Bomberman::inflictGhostDamage() {
	if ( m_noOfLives == 1 ) {
		m_board->setGameLost();
	}
	else {
		--m_noOfLives;
		m_board->tempReset();
	}
}

int Bomberman::getBombRow() const {
	return m_bRow;
}

int Bomberman::getBombCol() const {
	return m_bCol;
}

bool Bomberman::isPowerUpEaten() const {
	return m_isPowerUpEaten;
}

void Bomberman::setPowerUpEaten( bool status ) {
	m_isPowerUpEaten = status;
}