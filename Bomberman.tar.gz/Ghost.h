/*
 * Ghost.h
 *
 *  Created on: May 7, 2017
 *      Author: amer
 */

#ifndef GHOST_H_
#define GHOST_H_

#include <string>
#include <queue>
#include <algorithm>
#include "MyEnums.h"
#include "util.h"

using namespace std;

class Board;

class Ghost {

public:
	Ghost();
	Ghost( Board*, string );

	GhostDirection getNextDirection( int sr, int sc, int fr, int fc );

	ColorNames getGhostColor() const;
	GhostMode getGhostMode() const;
	string getGhostName() const;

	void move();
	void moveUp();
	void moveDown();
	void moveRight();
	void moveLeft();

	void kill();
	bool isValid( int, int );
	bool isKilled() const;
	void setGhostAlive();

	int getRespawnTimer() const;
	void incrementRespawnTimer();
	void resetRespawnTimer();

	void setSpawnStatus( bool );
	bool shouldBeSpawned() const;
	bool isSpawned() const;
	void spawn( GhostMode = CHASE );
	void setSpawnColumn();
	void setSpawnRow( int rowDistance = 1 );
	void respawn();

	int getCurrentRow() const;
	int getCurrentCol() const;

	int getPreviousRow() const;
	int getPreviousCol() const;

	int getTargetRow() const;
	int getTargetCol() const;

	void resetCurrentPosition();
	void setTarget( int row, int col );
	void setMode( GhostMode );

	friend ostream& operator<<( ostream&, const Ghost* ptr );
	
private:
	Board* m_board;
	ColorNames m_color;

	GhostMode m_ghostMode;
	string m_name;
	bool m_isSpawned;

	int m_respawnTimer;
	bool m_isKilled;

	/* Current Row and Column. */
	int m_cRow;
	int m_cCol;

	/* Previous Row and Column. */
	int m_pRow;
	int m_pCol;

	/* Target Row and Column. */
	int m_tRow;
	int m_tCol;

};

#endif /* GHOST_H_ */
