/*
 * Cell.cpp
 *
 *  Created on: May 7, 2017
 *      Author: amer
 */

#include "Cell.h"

Cell::Cell()
: m_brickType( NILL ),
  m_hasBomberman( false ),
  m_hasBomb( false ),
  m_hasEnergizer( false ),
  m_hasGhost( false ),
  m_hasPowerUp( false )
{
}

void Cell::setBrick( BoardParts brick ) {
	if ( brick == NILL or brick == S_BRICK or brick == R_BRICK or brick == G_BRICK ) {
		m_brickType = brick;
	}
	else {
		cout << brick;
		cout << "Invalid Brick Type in Cell::addBrick()" << endl;
	}
}

void Cell::setBomb( bool status ) {
	m_hasBomb = status;
}

void Cell::setBomberman( bool bomberManStatus ) {
	m_hasBomberman = bomberManStatus;
}

void Cell::setEnergizer( bool status ) {
	m_hasEnergizer = status;
}

void Cell::addGhost( Ghost* ghost ) {
	m_ghosts.push_back( ghost );
	m_hasGhost = true;
}

void Cell::reset() {
  m_hasBomberman = false;
  m_hasBomb = false;
  m_hasEnergizer = false;
  m_hasGhost = false;
  m_hasPowerUp = false;
  
  for ( int i = 0; i < m_ghosts.size(); ++i ) {
	m_ghosts.at(i)->setSpawnStatus( false );
	m_ghosts.at(i)->resetCurrentPosition();
	m_ghosts.at(i)->setMode( CHASE );
  }
 	 m_ghosts.clear();
	
}

void Cell::removeGhost( Ghost* ghost ) {

	for ( int i = 0; i < m_ghosts.size(); ++i ) {
		if ( m_ghosts.at(i) == ghost ) 
			m_ghosts.erase( m_ghosts.begin() + i );
	}
	if ( m_ghosts.empty() ) 
		m_hasGhost = false;
}

void Cell::killGhosts() {
	for ( int i = 0; i < m_ghosts.size(); ++i ) {
		m_ghosts.at(i)->kill();
	}
	m_ghosts.clear();
	m_hasGhost = false;
}

Ghost* Cell::getGhost( int index ) {
	return m_ghosts.at( index );
}

int Cell::getNoOfGhosts() const {
	return m_ghosts.size();
}

bool Cell::operator!() {
	if ( m_brickType == NILL )
		return true;
	else
		return false;
}

void Cell::setPowerUp( bool status ) {
	m_hasPowerUp = status;
}

int Cell::getBrick() const {
	return m_brickType;
}

void Cell::destroyBrick() {
	m_brickType = NILL;
}

ostream& operator<<( ostream& op, const Cell& cell ) {
	if ( cell.getBrick() != NILL )
		op << cell.getBrick();

	else if ( cell.hasBomberman() ) 
		op << "4";
	else if ( cell.hasGhost() )
		op << "9";
	// else if ( cell.hasEnergizer() ) 
	// 	op << "5";
	else if ( cell.hasBomb() )
		op << "6";
	// else if ( cell.hasPowerUp() ) 
	// 	op << "8";
	else 
		op << NILL;
	return op;
}






