#ifndef _BOARD_H_
#define _BOARD_H_

#include <chrono>
#include <thread>
#include <GL/glut.h>
#include <string>
#include <iostream>
#include "MyEnums.h"
#include "Bomberman.h"
#include "Cell.h"
#include "util.h"

using namespace std;

class Board {

private:

	Bomberman bomberman;

	vector< Ghost* > ghosts;
	GhostMode ghostMode;

	ColorNames pcolor, bcolor, gcolor;

	int noOfSpawnedGhosts;
	int xcellsize, ycellsize;
	int width, height;
	int totalBreakableBricks;
	int noOfBreakableBricks;
	
	int pwrUpRow;
	int pwrUpCol;

	bool energizerState;  /* eaten or not */
	bool reset;

	bool gameStateChange;
	bool gameLost;
	bool gameWon;

public:
	static const int COLS;
	static const int ROWS;
	
	Board(int xsize = 8, int ysize = 8);

	void InitalizeBoard(int, int);
	void Draw();

	void tempReset();
	void totalReset();

	void removeCell( int row, int col );

	Cell& operator()( int row, int col );
	
	void setGameLost() {
		gameStateChange = true;
		gameLost = true;
	}

	void setGameWon() {
		gameStateChange = true;
		gameWon = true;
	}

	bool hasGameStateChanged() const {
		return gameStateChange;
	}
 
	void removeGameChangeState() {
		gameStateChange = false;
		gameWon = gameLost = false;
	}

	GhostMode getGhostMode() const {
		return ghostMode;
	}
	Bomberman& getBomberman() {
		return bomberman;
	}
	static int GetColumns() {
		return COLS;
	}
	static int GetRows() {
		return ROWS;
	}

	void setGhostMode( GhostMode );
	void initializeGhosts();
	void spawnGhosts();
	void moveGhosts();

	void drawCircle( int row, int col, ColorNames color, int size = 15 );
	void DrawBomberman( int row, int col );
	void DrawBomb( int row, int col );
	void DrawGhost( int row, int col, ColorNames color );

	float Row2Pixel( int );
	float Col2Pixel( int );

	void setEnergizerEaten( bool );
	bool isEnergizerEaten() const;

	void generatePowerUp();

	void decrementGhostCounter() {
		--noOfSpawnedGhosts;
	}
	void killGhost( Ghost* );

	int GetCellSize() {
		return xcellsize;
	}

	int getTotalBricks() {
		return totalBreakableBricks;
	}
	int getRemainingBricks() {
		return noOfBreakableBricks;
	}

	bool isTotalReset() const {
		return reset;
	}

	void removeResetState() {
		reset = false;
	}

	bool removePowerUp();
	void gameLose();

	friend ostream& operator<<( ostream&, const Board& );

};

#ifdef WITH_TEXTURES
void RegisterTextures();
#endif

#endif
