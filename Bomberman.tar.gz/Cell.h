#ifndef CELL_H_
#define CELL_H_

#include "MyEnums.h"
#include "Ghost.h"
#include <vector>
#include <iostream>

using namespace std;

class Cell {

public:
	Cell();

	void setBrick( BoardParts brickType );
	void setBomb( bool );
	void setBomberman( bool );
	void setPowerUp( bool );
	void setEnergizer( bool );
	
	void addGhost( Ghost* );
	void removeGhost( Ghost* );
	
	bool operator!();

	Ghost* getGhost( int );
	int getNoOfGhosts() const;
	
	bool hasGhost() const {
		return m_hasGhost;
	}
	bool hasBomberman()const {
		return m_hasBomberman;
	}
	bool hasBomb() const {
		return m_hasBomb;
	}
	bool hasEnergizer() const {
		return m_hasEnergizer;
	}
	bool hasPowerUp() const {
		return m_hasPowerUp;
	}

	void reset();
	void killGhosts();

	int getBrick() const;
	void destroyBrick();

	friend ostream& operator<<( ostream& op, const Cell& );

private:
	int m_brickType;

	bool m_hasBomberman;
	bool m_hasBomb;
	bool m_hasEnergizer;
	bool m_hasGhost;
	bool m_hasPowerUp;

	vector< Ghost* > m_ghosts;

};

#endif /* CELL_H_ */
