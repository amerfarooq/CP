#ifndef _BOMBERMAN_H_
#define _BOMBERMAN_H_

#include "MyEnums.h"
#include "Cell.h"

class Board;

class Bomberman {

public:

	Bomberman( Board*, int sRow = 11, int sCol = 1 );

	void moveUp();
	void moveDown();
	void moveRight();
	void moveLeft();

	void resetCounters();
	bool isPowerUpEaten() const;
	void setPowerUpEaten( bool );

	void inflictExplosionDamage();
	void inflictGhostDamage();
	void respawn();

	int getCurrentRow() const;
	int getCurrentCol() const;

	int getScore() const;
	int getNoOfLives() const;

	int getBombRadius() const;
	void setBombRadius( int );

	void dropBomb();
	bool isBombDropped();
	void setBombDropped( bool );

	void blowCell( int row = -1, int col = -1, ExplosionMode mode = NORMAL );
	void blowUp( int row, int col, ExplosionMode mode = NORMAL );
	void blowDown( int row, int col, ExplosionMode mode = NORMAL );
	void blowRight( int row, int col, ExplosionMode mode = NORMAL );
	void blowLeft( int row, int col, ExplosionMode mode = NORMAL );

	int getBombRow() const;
	int getBombCol() const;

private:
	Board* m_board;

	/* Starting Row and Column */
	int m_sRow;
	int m_sCol;

	/* Current Row and Column */
	int m_cRow;
	int m_cCol;

	/* Bomb Row and Column */
	int m_bRow;
	int m_bCol;
	bool m_isBombDropped;

	int m_noOfLives;
	int m_bombRadius;
	int m_score;

	bool m_isPowerUpEaten;

};


#endif
