#include "Board.h"
#include <cstdio>


const int Board::COLS = 17;
const int Board::ROWS = 14;

static Cell board_array [Board::ROWS][Board::COLS];
static Cell original_board [Board::ROWS][Board::COLS];

//#ifdef WITH_TEXTURES
const int nbricks = 3;

GLuint texture[nbricks];
GLuint tid[nbricks];
string tnames[] = {"solid.png", "brick.png", "brick-green.png"};
GLuint mtid[nbricks];
int cwidth = 60, cheight = 60;

void RegisterTextures()
/*Function is used to load the textures from the
 * files and display*/
{
	glGenTextures(nbricks, tid);

	vector<unsigned char> data;

	for (int i = 0; i < nbricks; ++i) {

		ReadImage(tnames[i], data);
		if (i == 0) {
			int length = data.size();

		}

		cout << " Texture Id=" << tid[i] << endl;
		mtid[i] = tid[i];

		glBindTexture(GL_TEXTURE_2D, tid[i]);

		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
				GL_LINEAR_MIPMAP_NEAREST);

		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		bool wrap = true;
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S,
				wrap ? GL_REPEAT : GL_CLAMP);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T,
				wrap ? GL_REPEAT : GL_CLAMP);


		gluBuild2DMipmaps(GL_TEXTURE_2D, 3, cwidth, cheight, GL_RGB,
				GL_UNSIGNED_BYTE, &data[0]);
	}
}

void Drawbrick(const BoardParts &cname, float fx, float fy, float fwidth,
		float fheight)
{

	glPushMatrix();
	glEnable (GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, mtid[cname - 1]);
//	glTranslatef(0, 0, 0);
//	glRotatef(-M_PI / 2, 0, 0, 1);
	glBegin (GL_QUADS);
	glTexCoord2d(0.0, 0.0);
	glVertex2d(fx, fy);
	glTexCoord2d(1.0, 0.0);
	glVertex2d(fx + fwidth, fy);
	glTexCoord2d(1.0, 1.0);
	glVertex2d(fx + fwidth, fy + fheight);
	glTexCoord2d(0.0, 1.0);
	glVertex2d(fx, fy + fheight);
	glEnd();

	glColor4f(1, 1, 1, 1);

//	glBindTexture(GL_TEXTURE_2D, 0);

	glDisable(GL_TEXTURE_2D);
	glPopMatrix();

	//glutSwapBuffers();
}
//#endif

const int npmvertices = 1220;
GLfloat pmvertices[npmvertices][2];
void InitPMVertices(float radius) {

	float hdegree = (M_PI - M_PI / 2.0) / 360.0;
	float angle = M_PI + M_PI / 6.0;
	for (int i = 0; i < npmvertices; ++i) {
		pmvertices[i][0] = radius * cos(angle);
		pmvertices[i][1] = radius * sin(angle);
		angle += hdegree;
	}
}

float Board::Row2Pixel( int row ) {
	return ycellsize * ( ROWS - 2 - row + 0.5 );
}

float Board::Col2Pixel( int col ) {
	return xcellsize * ( col + 0.33 );
}

void Board::DrawBomberman( int row, int col ) {

	float sx = Col2Pixel( col );
	float sy = Row2Pixel( row );
	float radius = xcellsize / 2 - 2;

	glColor3fv(colors[YELLOW]);
	InitPMVertices(radius);
	glBegin (GL_TRIANGLE_FAN);
	glVertex4f(sx, sy, 0, 1);
	for (int i = 0; i < npmvertices; ++i)
		glVertex4f(sx + pmvertices[i][0], sy + pmvertices[i][1], 0, 1);
	glEnd();
	DrawCircle(sx - radius + radius / 2, sy + (radius - radius / 2),
			radius / 10, colors[BLACK]);
}

void Board::DrawBomb( int row, int col ) {
	float sx = Col2Pixel( col );
	float sy = Row2Pixel( row );

	DrawCircle( sx, sy, 15, colors[RED]);
}

void Board::drawCircle( int row, int col, ColorNames color, int size ) {
	float sx = Col2Pixel( col );
	float sy = Row2Pixel( row );

	DrawCircle( sx, sy, size, colors[color] );
}

void Board::DrawGhost( int row, int col, ColorNames color ) {
	int y = Row2Pixel( row ) - 22;
	int x = Col2Pixel( col ) - 18;
	float gw = 0.6 * xcellsize;
	float gh = 0.8 * ycellsize;
	int ogw = 6, ogh = 7;

	glPushMatrix();
	float sx = (float) gw / ogw, sy = (float) gh / ogh;
	glTranslatef(x, y, 1);
	glScalef(sx, sy, 1);

	// Draw Enemy
	DrawRoundRect(0, 1, 6, 3, colors[color]);
	DrawCircle(3, 4, 3.01, colors[color]);
	glPushMatrix();
	glScalef(0.9, 1.1, 1);

	// legs
	DrawCircle(0.75, 1, 0.75, colors[color]);
	DrawCircle(3.25, 1, 0.75, colors[color]);
	DrawCircle(5.85, 1, 0.75, colors[color]);

	glPopMatrix();

	// eyes
	glPushMatrix();
	glScalef(0.9, 1.1, 1);
	DrawCircle(1.85, 3.95, 0.75, colors[WHITE]);
	DrawCircle(4.95, 3.95, 0.75, colors[WHITE]);
	glPopMatrix();

	// eyes
	DrawCircle(1.65, 4.25, 0.45, colors[BLUE]);
	DrawCircle(4.45, 4.25, 0.45, colors[BLUE]);
	glPopMatrix();
}


void Board::InitalizeBoard(int w, int h) {
	width = w;
	height = h;

	for (int i = 0; i < ROWS - 1; ++i) {
		for (int j = 0; j < COLS; ++j) {

			if (i == 0 || i == ROWS - 2 || j == 0 || j == COLS - 1) {
				board_array[i][j].setBrick( S_BRICK );
				original_board[i][j].setBrick( S_BRICK );

			}
			else if (i % 2 == 0 && j % 2 == 0) {
				board_array[i][j].setBrick( S_BRICK );
				original_board[i][j].setBrick( S_BRICK );

			}
			else {
				BoardParts brickType =
						(GetRandInRange(0, 10)) < 8 ? NILL :
						(GetRandInRange(0, 10)) < 8 ? G_BRICK : R_BRICK;

				if ( brickType != NILL ) {
					++totalBreakableBricks;
				    	++noOfBreakableBricks;
				}
				board_array[i][j].setBrick( brickType );
				original_board[i][j].setBrick( brickType );

			}
		}
	}	
	// Placing Energizers on 4 corners of board.
	board_array[1][1].setEnergizer( true );
	board_array[1][15].setEnergizer( true );
	board_array[11][15].setEnergizer( true );
	board_array[11][1].setEnergizer( true );
	original_board[11][15].setEnergizer( true );
	original_board[1][1].setEnergizer( true );
	original_board[1][15].setEnergizer( true );
	original_board[11][1].setEnergizer( true );
	
	// Manually removing some bricks.
	board_array[5][13].setBrick( NILL );
	original_board[5][13].setBrick( NILL );

	board_array[9][11].setBrick( NILL );
	original_board[9][11].setBrick( NILL );

	// Left Portal
	board_array[6][0].setBrick( NILL );
	original_board[6][0].setBrick( NILL );

	// Rigt Portal
	board_array[6][16].setBrick( NILL );
	original_board[6][16].setBrick( NILL );
	
	totalBreakableBricks -= 2;
	noOfBreakableBricks -= 2;
	
	initializeGhosts();
}

Board::Board( int xsize, int ysize )
: bomberman( this, 7, 7 )
{
	xcellsize = xsize;
	ycellsize = ysize;
	pcolor = CHOCOLATE;
	bcolor = ORANGE_RED;
	gcolor = PINK;
	ghostMode = CHASE;
	energizerState = false;
	pwrUpRow = -1;
	pwrUpCol = -1;
	gameLost = gameWon = gameStateChange = false;
}

int circleBlipTimer = 0;
bool isCircleBlipping = true;
bool shouldCircleBlip() {
  	// A function which alternates between
  	// returning true and false after every 1.5 second.

  	if ( isCircleBlipping ) {
  		++circleBlipTimer;

  		if ( circleBlipTimer == 15 ) {
  			circleBlipTimer = 0;
  			isCircleBlipping = false;
  		}
  	}
  	else {
  		++circleBlipTimer;

  		if ( circleBlipTimer == 15 ) {
  			circleBlipTimer = 0;
  			isCircleBlipping = true;
  		}
  	}
  	return isCircleBlipping;
}

void Board::Draw() {
	glColor3f(0, 0, 1);
	glPushMatrix();

	if ( gameStateChange ) {  // If either game won or lost.
			
			if ( gameWon ) {
				
				for (int i = 0; i < 10; ++i)
				{
					DrawString( 440, 800, "You Win!", colors[5] );
				}
				removeGameChangeState();
				totalReset();
			}
			else if ( gameLost ) {
				for (int i = 0; i < 10; ++i)
				{
					DrawString( 440, 800, "You Lose!", colors[5] );
				}
				removeGameChangeState();
				gameStateChange = false;
				totalReset();
			}
	}	


	if ( noOfSpawnedGhosts != ghosts.size() ) {
		spawnGhosts();
	}
	for ( int i = ROWS - 2, y = 0; i >= 0; --i, y += xcellsize ) {
		for ( int j = 0, x = 0; j < COLS; j++, x += ycellsize ) {
			
			Cell& cell = board_array[i][j];

			// If there is no brick
			 if ( !cell ) {
				 
			 	  if ( cell.hasBomberman() ) {
			  	  	DrawBomberman( i, j );
			 	  }
			  	  // Draw all ghosts a cell has. Check if ghosts are
			  	  // frightened. If so, draw them in NAVY, otherwise
			  	  // draw them in their natural color.
			  	  if ( cell.hasGhost() ) {
			  	  	 for ( int i = 0; i < cell.getNoOfGhosts(); ++i ) {
				  		
				  		 int ghostRow = cell.getGhost(i)->getCurrentRow();
				  		 int ghostCol = cell.getGhost(i)->getCurrentCol();
				  		 
				  		 ColorNames ghostColor = cell.getGhost(i)->getGhostColor();

						 if ( ghostMode == FRIGHTENED ) {
				  		 	DrawGhost( ghostRow, ghostCol, NAVY );
				  		 }	
				  		 else {
				  		 	DrawGhost( ghostRow, ghostCol, ghostColor );	
				  		 }	
			  		 }
			  	  }
			  	  if ( cell.hasBomb() ) {
			  	  	DrawBomb( i, j );
			  	  }
			  	  if ( cell.hasEnergizer() ) {
			  	  		if ( shouldCircleBlip() )
			  	  			drawCircle( i, j, BLUE, 8 );
			  	  		else
			  	  			drawCircle( i, j, BLUE );
			  	  }
			  	  if ( cell.hasPowerUp() ) {
			  	  		if ( shouldCircleBlip() )
			  	  			drawCircle( i, j, YELLOW, 8 );
			  	  		else
			  	  			drawCircle( i, j, YELLOW );
			  	  }
			 }
			 else {

			  	switch( cell.getBrick() ) {

			  		case S_BRICK:
			  			DrawRectangle(x - 10, y, ycellsize, xcellsize, colors[SLATE_GRAY]);
			  			DrawLine(x - 10, y, x - 10 + ycellsize, y, 2, colors[BLACK]);
			  			break;

			  		case G_BRICK:
			  			DrawRectangle(x - 10, y, ycellsize, xcellsize, colors[MEDIUM_AQUA_MARINE]);
			  			break;

			  		case R_BRICK:
			  			DrawRectangle(x - 10, y, ycellsize, xcellsize, colors[DARK_ORANGE]);
			  			break;
			  	}
			 }
		}
	}
	DrawString( 30, 800, "Score: " + Num2Str( bomberman.getScore()), colors[5] );
	DrawString( 790, 800, "Lives Remaining: " + Num2Str( bomberman.getNoOfLives()), colors[5] );
	
	if ( noOfBreakableBricks == 0 ) {
		setGameWon();
	}
	//cout << *this;
	glPopMatrix();
}

void Board::setEnergizerEaten( bool val ) {
	energizerState = val;
}

bool Board::isEnergizerEaten() const {
	return energizerState;
}

void Board::setGhostMode( GhostMode mode ) {
	ghostMode = mode;
	for ( int i = 0; i < ghosts.size(); ++i ) 
			ghosts.at(i)->setMode( mode );
}

void Board::initializeGhosts() {
	ghosts.push_back( new Ghost( this, "Pinky" ));
	ghosts.push_back( new Ghost( this, "Blinky" ));
	ghosts.push_back( new Ghost( this, "Inky" ));
	ghosts.push_back( new Ghost( this, "Clyde" ));
}

void Board::spawnGhosts() {
	/* Check if ghost has been spawned. If it hasn't, check
	 * if it should be spawned i.e. its spawn conditions are
	 * being met. If they are, spawn the ghost.*/
	for ( int i = 0; i < ghosts.size(); ++i ) {
		Ghost* const ghost = ghosts.at(i);

		if ( !ghost->isSpawned() and ghost->shouldBeSpawned()) {

			// Incase ghost is killed by a bomb, the timer will
			// 2 seconds before spawning it again.
			if ( ghost->isKilled() and ghost->getRespawnTimer() <= 20 ) {
				ghost->incrementRespawnTimer();
				return;
			}
			else if ( ghost->isKilled() and ghost->getRespawnTimer() > 20 ) {
				ghost->resetRespawnTimer();
				ghost->setGhostAlive();
			}
			ghost->spawn();
			++noOfSpawnedGhosts;
		}
	}
}

void Board::moveGhosts() {
	for ( int i = 0; i < ghosts.size(); ++i ) {
		ghosts.at(i)->move();
	}
}

bool Board::removePowerUp() {
		board_array [pwrUpRow][pwrUpCol].setPowerUp( false );
		
		pwrUpCol = -1;
		pwrUpRow = -1;
		
		bomberman.setPowerUpEaten( false );
	}

void Board::generatePowerUp() {
	pwrUpRow = GetRandInRange( 2, 11 );
	
	while ( true ) {
		pwrUpCol = GetRandInRange( 1, 15 );

		if ( !board_array [pwrUpRow][pwrUpCol] or                 // No brick.
			 !board_array [pwrUpRow][pwrUpCol].hasBomberman()	  // No bomberman.
			)
			break;
	}
		
	board_array [pwrUpRow][pwrUpCol].setPowerUp( true );
	original_board [pwrUpRow][pwrUpCol].setPowerUp( true );
}

Cell& Board::operator()( int row, int col ) {
	return board_array[row][col];
}

void Board::tempReset() {
	bomberman.respawn();
	/* By setting ghosts = 0, Board::Draw is forced to spawn them
     * all again. Since Ghosts::shouldBeSpawned's return will be
     * unaffected, ONLY the ghosts that were previously on the 
     * board will spawned again.
	 */
	noOfSpawnedGhosts = 0;                       
	
	for ( int i = 0; i < ROWS - 1; ++i ) {
		for ( int j = 0; j < COLS; ++j ) {
			board_array[i][j].setBomb( false );
			board_array[i][j].setPowerUp( false );
		}
	}
	for ( int i = 0; i < ghosts.size(); ++i ) {
		ghosts.at(i)->respawn();
	}
	ghostMode = CHASE;

	/* Wait 3 seconds after reset */
	std::this_thread::sleep_for(std::chrono::milliseconds(2500));
	glutPostRedisplay();
}

void Board::totalReset() {
	reset = true;
	// Replace current board with original board.
	for ( int i = 0; i < ROWS - 1; ++i ) {
		for ( int j = 0; j < COLS; ++j ) {
			board_array[i][j].reset();
			board_array[i][j] = original_board[i][j];
		}
	}
	// Set lives and score counter back to 0.
	bomberman.resetCounters();
	bomberman.setBombRadius( 1 );
	
	noOfBreakableBricks = totalBreakableBricks;
	std::this_thread::sleep_for(std::chrono::milliseconds(2000));
	tempReset();
}


void Board::killGhost( Ghost* gPtr ) {
	for ( int i = 0; i < ghosts.size(); ++i ) {
		if ( ghosts.at(i) == gPtr )
			ghosts.erase( ghosts.begin() + i );
	}
}

void Board::removeCell( int row, int col ) {
	if ( row < ROWS and row >= 0 and
	     col < COLS and col >= 0    )
	{
		board_array[row][col].destroyBrick();
		--noOfBreakableBricks;
	}
}

void Board::gameLose() {
	DrawString( 440, 800, "You Lose!", colors[35] );
	totalReset();
}

ostream& operator<<( ostream& op, const Board& board ) {
	
	for ( int i = 0; i <= board.ROWS - 2; ++i ) {
		for ( int j = 0; j < board.COLS ; ++j) {
				op << board_array[i][j] << " ";
		}
		op << endl;
	}
	op << endl << endl;
	return op;
}
